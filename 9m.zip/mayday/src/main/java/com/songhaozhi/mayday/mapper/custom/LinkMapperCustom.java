package com.songhaozhi.mayday.mapper.custom;


public interface LinkMapperCustom {

}