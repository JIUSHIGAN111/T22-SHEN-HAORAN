package kr.ac.jnu.sw.controller;

import kr.ac.jnu.sw.domain.GT;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TranslateController {

    @GetMapping("/translate")
    public String index(){
        return "translate";
    }

    @GetMapping("/tranC")
    public String tranc(@RequestParam("chinese") String chinese, Model model) throws Exception {

        String txt=chinese;
        GT g = GT.getInstance();
        System.out.println( g.translateText(txt,"auto","ko"));
        String result=g.translateText(txt,"auto","ko");
        model.addAttribute("ret",result);
        return "translate";
    }
    @GetMapping("/tranK")
    public String trank(@RequestParam("kora") String kora, Model model) throws Exception {

        String txt=kora;
        GT g = GT.getInstance();
        System.out.println( g.translateText(txt,"auto","zh_cn"));
        String result=g.translateText(txt,"auto","zh_cn");
        model.addAttribute("ret1",result);
        return "translate";
    }
}
