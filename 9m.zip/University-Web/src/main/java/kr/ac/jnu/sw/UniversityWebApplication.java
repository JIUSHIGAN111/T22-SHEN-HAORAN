package kr.ac.jnu.sw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversityWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(UniversityWebApplication.class, args);
    }

}
