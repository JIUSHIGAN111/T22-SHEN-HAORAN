package kr.ac.jnu.sw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
